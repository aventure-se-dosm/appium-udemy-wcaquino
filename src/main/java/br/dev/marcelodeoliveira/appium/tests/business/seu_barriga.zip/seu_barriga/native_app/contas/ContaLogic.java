package br.dev.marcelodeoliveira.appium.tests.business.seu_barriga.native_app.contas;

import br.dev.marcelodeoliveira.appium.core.BasePage;
import br.dev.marcelodeoliveira.appium.tests.business.seu_barriga.native_app.SeuBarrigaNativoLogic;

public class ContaLogic extends SeuBarrigaNativoLogic {

	private ContaPage contasPage;

	@Override
	protected void setupPages() {
		this.contasPage = new ContaPage();
	}

	@Override
	protected void setupPages(BasePage... pages) {
		// TODO Auto-generated method stub
		
	}

}
