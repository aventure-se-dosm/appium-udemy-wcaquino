package br.dev.marcelodeoliveira.appium.tests.business.seu_barriga.native_app;

import org.junit.Test;

import br.dev.marcelodeoliveira.appium.core.CTAppiumBaseTestVersionable;
import br.dev.marcelodeoliveira.appium.tests.business.elements_interaction.menu.MenuLogic;
import br.dev.marcelodeoliveira.appium.tests.business.seu_barriga.native_app.login.LoginLogic;

public abstract class SeuBarrigaNativoTest extends CTAppiumBaseTestVersionable {

	private SeuBarrigaNativoLogic sbLogic;
	private MenuLogic menuLogic;
	private LoginLogic loginLogic;

	@Test
	public void deveCadastrarContaComSucesso() {

	}

	@Override
	protected void setupLogic() {
		this.loginLogic = new LoginLogic();
		this.menuLogic = new MenuLogic();
		menuLogic.clicaSeuBarrigaNativo();
		loginLogic.login();
		sbLogic.defaultTestSetUpReset();

	}

}
