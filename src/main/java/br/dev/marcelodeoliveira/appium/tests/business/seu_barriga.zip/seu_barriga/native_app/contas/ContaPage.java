package br.dev.marcelodeoliveira.appium.tests.business.seu_barriga.native_app.contas;

import br.dev.marcelodeoliveira.appium.core.BasePage;

public class ContaPage extends BasePage {

}
