package br.dev.marcelodeoliveira.appium.tests.business.seu_barriga.native_app.login;

import br.dev.marcelodeoliveira.appium.core.BasePage;
import br.dev.marcelodeoliveira.appium.tests.business.seu_barriga.native_app.SeuBarrigaNativoLogic;

public class LoginLogic extends SeuBarrigaNativoLogic{

	private LoginPage loginPage;

	@Override
	protected void setupPages(BasePage... pages) {
		this.loginPage = new LoginPage();
		
	}

}
